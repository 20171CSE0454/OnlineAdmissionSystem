package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.exceptions;

public class AddressAlreadyExistsException extends RuntimeException{
        /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public AddressAlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}
	
	public AddressAlreadyExistsException(String message) {
		super(message); 

}
}