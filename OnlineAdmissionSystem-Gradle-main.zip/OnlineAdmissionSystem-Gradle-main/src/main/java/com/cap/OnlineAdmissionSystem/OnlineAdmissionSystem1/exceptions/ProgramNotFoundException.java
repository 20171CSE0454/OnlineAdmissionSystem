package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.exceptions;

public class ProgramNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4362439241380110958L;

	public ProgramNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
