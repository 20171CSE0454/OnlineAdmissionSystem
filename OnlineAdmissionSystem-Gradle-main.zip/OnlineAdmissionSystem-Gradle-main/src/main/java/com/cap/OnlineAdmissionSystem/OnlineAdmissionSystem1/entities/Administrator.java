package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.entities;

public class Administrator extends User{

	public Administrator(int userId, String firstName, String middleName, String lastName, String email,
			String mobileNumber, String aadharCardNo) {
		super(userId, firstName, middleName, lastName, email, mobileNumber, aadharCardNo);
		
	}

}
