package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.exceptions;

public class ApplicationAlreadyExistsException extends RuntimeException {
	public ApplicationAlreadyExistsException() {
		
	}
	public ApplicationAlreadyExistsException(String message) {
		super(message);
	}
}


