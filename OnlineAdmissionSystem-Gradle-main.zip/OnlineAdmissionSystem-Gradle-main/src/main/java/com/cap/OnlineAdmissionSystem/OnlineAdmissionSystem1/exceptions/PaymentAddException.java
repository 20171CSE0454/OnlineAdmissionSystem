package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.exceptions;

public class PaymentAddException extends RuntimeException{
	public PaymentAddException() {}
	
	public PaymentAddException(String message) {
		super(message);
	}

}
