package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.exceptions;

public class DeletionException extends RuntimeException{
public DeletionException() {
		
	}
	public DeletionException(String message) {
		super(message);
	}
}