package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1.entities.Login;


public interface ILoginRepository  extends JpaRepository<Login, Integer>  {

	Login findByUserId(int userId);

	

}
