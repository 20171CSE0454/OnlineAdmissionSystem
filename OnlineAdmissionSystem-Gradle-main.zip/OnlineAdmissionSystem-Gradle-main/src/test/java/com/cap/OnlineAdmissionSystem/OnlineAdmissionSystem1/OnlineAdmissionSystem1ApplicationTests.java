package com.cap.OnlineAdmissionSystem.OnlineAdmissionSystem1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineAdmissionSystem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
